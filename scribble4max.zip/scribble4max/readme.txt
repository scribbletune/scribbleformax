Scribble 4 Max!

This is a WIP Max 4 Live plugin that enables using scribbletune directly inside Ableton Live! It s a riff generator that creates A and B parts and then joins them as AAAB. It uses the pattern, root note, octave and scale that you choose.

Visit scribbletune.com to learn more!